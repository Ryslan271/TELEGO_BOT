
import sqlalchemy as sa
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'user'

    id = sa.Column(sa.Integer,
                   primary_key=True, autoincrement=True)
    name = sa.Column(sa.String, nullable=True)
    name1 = sa.Column(sa.String, nullable=True)
    url = sa.Column(sa.String, nullable=True)
    iduser = sa.Column(sa.String, nullable=True)
