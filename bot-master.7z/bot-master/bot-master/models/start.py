import telebot

# токен
bot = telebot.TeleBot('853656809:AAFcImI2UB3jG7x4ATKfyZ5ZNdNGtLYRJw0')
